const mysql = require('mysql2');
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT || 3306
});

const filePath = path.join(__dirname, 'leads.xlsx');
if (!fs.existsSync(filePath)) {
  console.error('❌ leads.xlsx not found. Please upload your Excel file as leads.xlsx');
  process.exit(1);
}

const workbook = XLSX.readFile(filePath);
const sheet = workbook.Sheets['Leads'];
const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });

const rows = data.slice(1).filter(row => row.some(c => c && c.toString().trim() !== ''));

if (rows.length === 0) {
  console.log('No data to import.');
  process.exit(0);
}

const values = rows.map(row => {
  while (row.length < 12) row.push('');
  return row.slice(0, 12).map(c => (c || '').toString().trim());
});

const sql = `INSERT INTO leads 
  (student_name, source, contact_01, contact_02, school, stream, call_round, call_status, result, followup_date, remarks_01, remarks_02) 
  VALUES ?`;

db.query(sql, [values], (err, result) => {
  if (err) {
    console.error('❌ Import failed:', err.message);
    db.end();
    process.exit(1);
  }
  console.log(`✅ Successfully imported ${result.affectedRows} leads.`);
  db.end();
});