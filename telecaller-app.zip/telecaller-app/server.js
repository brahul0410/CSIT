const express = require('express');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const XLSX = require('xlsx');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-me';

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ====================== MYSQL POOL ======================
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

pool.on('error', (err) => {
  console.error('Pool error:', err.message);
});

const db = pool;

// ====================== INIT TABLES ======================
db.query(`
  CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(100),
    role ENUM('Admin','Caller') NOT NULL
  );
  CREATE TABLE IF NOT EXISTS leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(255),
    source VARCHAR(100),
    contact_01 VARCHAR(20),
    contact_02 VARCHAR(20),
    school VARCHAR(255),
    stream VARCHAR(100),
    call_round INT,
    call_status VARCHAR(50),
    result VARCHAR(50),
    followup_date VARCHAR(20),
    remarks_01 TEXT,
    remarks_02 TEXT,
    caller_id INT,
    call_date DATETIME,
    FOREIGN KEY (caller_id) REFERENCES users(id) ON DELETE SET NULL
  );
`, (err) => {
  if (err) console.error('Table error:', err.message);
  else {
    console.log('✅ Tables ready');
    db.query(`
      INSERT IGNORE INTO users (email, name, role) VALUES 
      ('pylonstechnology@gmail.com', 'Pylons', 'Admin'),
      ('brahul0410@gmail.com', 'Rahul', 'Caller'),
      ('meenalg877@gmail.com', 'Meenal', 'Caller'),
      ('aniketsinha014@gmail.com', 'Aniket', 'Caller'),
      ('www.vandana191997@gmail.com', 'Vandana', 'Caller'),
      ('tameshwariy974@gmail.com', 'Tameshwari', 'Caller'),
      ('jagriti0402@gmail.com', 'Jagriti', 'Caller'),
      ('skantlautre@gmail.com', 'Skant', 'Caller')
    `);
  }
});

// ====================== AUTH ======================
function authenticate(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'No token' });
  const token = auth.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

function isAdmin(req, res, next) {
  if (req.user.role !== 'Admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ====================== LOGIN ======================
app.post('/api/login', (req, res) => {
  const { email } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err || results.length === 0) return res.status(401).json({ error: 'User not found' });
    const user = results[0];
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.json({ token, email: user.email, role: user.role, name: user.name });
  });
});

// ====================== LEADS CRUD ======================
app.get('/api/leads', authenticate, isAdmin, (req, res) => {
  db.query('SELECT * FROM leads', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/leads/my', authenticate, (req, res) => {
  db.query('SELECT * FROM leads WHERE caller_id = ?', [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.patch('/api/leads/:id', authenticate, (req, res) => {
  const { id } = req.params;
  const { call_round, call_status, result, remarks_01, remarks_02 } = req.body;
  const fields = [], values = [];
  if (call_round !== undefined) { fields.push('call_round = ?'); values.push(call_round); }
  if (call_status !== undefined) { fields.push('call_status = ?'); values.push(call_status); }
  if (result !== undefined) { fields.push('result = ?'); values.push(result); }
  if (remarks_01 !== undefined) { fields.push('remarks_01 = ?'); values.push(remarks_01); }
  if (remarks_02 !== undefined) { fields.push('remarks_02 = ?'); values.push(remarks_02); }
  values.push(id);
  db.query(`UPDATE leads SET ${fields.join(', ')} WHERE id = ?`, values, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, updated: result.affectedRows });
  });
});

app.post('/api/leads/bulk', authenticate, isAdmin, (req, res) => {
  const { rows } = req.body;
  if (!rows || !rows.length) return res.json({ success: true, count: 0 });
  const cleaned = rows
    .filter(r => r.some(c => c && c.trim() !== ''))
    .map(r => {
      while (r.length < 12) r.push('');
      return r.slice(0, 12).map(c => (c || '').toString().trim());
    });
  if (!cleaned.length) return res.json({ success: true, count: 0 });
  const values = cleaned.map(r => [r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11]]);
  const sql = `INSERT INTO leads 
    (student_name, source, contact_01, contact_02, school, stream, call_round, call_status, result, followup_date, remarks_01, remarks_02) 
    VALUES ?`;
  db.query(sql, [values], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, count: result.affectedRows });
  });
});

app.post('/api/leads/assign', authenticate, isAdmin, (req, res) => {
  const { callerEmail, leadIds } = req.body;
  if (!callerEmail || !leadIds?.length) return res.status(400).json({ error: 'Missing data' });
  db.query('SELECT id FROM users WHERE email = ? AND role = "Caller"', [callerEmail], (err, users) => {
    if (err || users.length === 0) return res.status(404).json({ error: 'Caller not found' });
    const callerId = users[0].id;
    const placeholders = leadIds.map(() => '?').join(',');
    db.query(`UPDATE leads SET caller_id = ? WHERE id IN (${placeholders})`, [callerId, ...leadIds], (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, assigned: result.affectedRows });
    });
  });
});

app.post('/api/leads/:id/log-call', authenticate, (req, res) => {
  const { id } = req.params;
  const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
  db.query('UPDATE leads SET call_date = ? WHERE id = ?', [now, id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

// ====================== USERS ======================
app.get('/api/users/callers', authenticate, isAdmin, (req, res) => {
  db.query('SELECT email, name, id FROM users WHERE role = "Caller"', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/users', authenticate, isAdmin, (req, res) => {
  const { email, name } = req.body;
  if (!email || !name) return res.status(400).json({ error: 'Missing fields' });
  db.query('INSERT IGNORE INTO users (email, name, role) VALUES (?, ?, "Caller")', [email, name], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, id: result.insertId });
  });
});

app.delete('/api/users/:email', authenticate, isAdmin, (req, res) => {
  const { email } = req.params;
  db.query('DELETE FROM users WHERE email = ? AND role = "Caller"', [email], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    db.query('UPDATE leads SET caller_id = NULL WHERE caller_id IN (SELECT id FROM users WHERE email = ?)', [email]);
    res.json({ success: true, deleted: result.affectedRows });
  });
});

// ====================== STATS ======================
app.get('/api/stats/stream', authenticate, isAdmin, (req, res) => {
  const stream = req.query.stream || 'All';
  let sql = 'SELECT result, COUNT(*) as count FROM leads';
  const params = [];
  if (stream !== 'All') { sql += ' WHERE stream = ?'; params.push(stream); }
  sql += ' GROUP BY result';
  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    const resultCounts = {};
    rows.forEach(r => { resultCounts[r.result || 'Blank'] = r.count; });
    let unattendedSql = 'SELECT COUNT(*) as count FROM leads WHERE caller_id IS NOT NULL AND (result IS NULL OR result = "")';
    if (stream !== 'All') { unattendedSql += ' AND stream = ?'; }
    db.query(unattendedSql, stream !== 'All' ? [stream] : [], (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ resultCounts, unattended: row[0]?.count || 0 });
    });
  });
});

app.get('/api/stats/calls', authenticate, isAdmin, (req, res) => {
  const { from, to, callerId } = req.query;
  let sql = 'SELECT DATE(call_date) as date, COUNT(*) as count FROM leads WHERE call_date IS NOT NULL';
  const params = [];
  if (from) { sql += ' AND DATE(call_date) >= ?'; params.push(from); }
  if (to) { sql += ' AND DATE(call_date) <= ?'; params.push(to); }
  if (callerId) { sql += ' AND caller_id = ?'; params.push(callerId); }
  sql += ' GROUP BY DATE(call_date) ORDER BY DATE(call_date)';
  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/stats/caller/:id/results', authenticate, isAdmin, (req, res) => {
  const { id } = req.params;
  db.query('SELECT result, COUNT(*) as count FROM leads WHERE caller_id = ? GROUP BY result', [id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    const resultCounts = {};
    rows.forEach(r => { resultCounts[r.result || 'Blank'] = r.count; });
    res.json(resultCounts);
  });
});

// ====================== EXCEL UPLOAD – SIMPLE & RELIABLE ======================
const upload = multer({ dest: 'uploads/' });

app.post('/admin/upload-excel', authenticate, isAdmin, upload.single('excelFile'), (req, res) => {
  if (!req.file) return res.status(400).send('No file uploaded');

  const filePath = req.file.path;
  try {
    // Read the workbook
    const workbook = XLSX.readFile(filePath);
    // Use the first sheet (most reliable)
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];

    // Convert to array of arrays
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });

    // Find first row that has any actual data (skip completely empty rows)
    let startRow = 0;
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      if (row.some(cell => cell && cell.toString().trim() !== '')) {
        startRow = i;
        break;
      }
    }

    // Check if the first data row looks like a header
    const firstRow = data[startRow];
    const headerKeywords = ['student', 'name', 'contact', 'source', 'school', 'stream', 'remark', 'followup', 'caller'];
    const isHeader = firstRow.some(cell => {
      const val = (cell || '').toString().trim().toLowerCase();
      return headerKeywords.some(keyword => val.includes(keyword));
    });

    let dataRows = [];
    if (isHeader) {
      // Start from the next row
      for (let i = startRow + 1; i < data.length; i++) {
        const row = data[i];
        if (row.some(cell => cell && cell.toString().trim() !== '')) {
          dataRows.push(row);
        }
      }
    } else {
      // Treat all non-empty rows as data
      for (let i = startRow; i < data.length; i++) {
        const row = data[i];
        if (row.some(cell => cell && cell.toString().trim() !== '')) {
          dataRows.push(row);
        }
      }
    }

    if (dataRows.length === 0) {
      fs.unlinkSync(filePath);
      return res.send('No data rows found. Ensure your Excel has data under a header row.');
    }

    // Pad each row to exactly 12 columns
    const values = dataRows.map(row => {
      while (row.length < 12) row.push('');
      return row.slice(0, 12).map(c => (c || '').toString().trim());
    });

    // Insert in batch
    const sql = `INSERT INTO leads 
      (student_name, source, contact_01, contact_02, school, stream, call_round, call_status, result, followup_date, remarks_01, remarks_02) 
      VALUES ?`;

    db.query(sql, [values], (err, result) => {
      // Delete temp file
      fs.unlinkSync(filePath);
      if (err) {
        console.error('Insert error:', err.message);
        return res.status(500).send('Import failed: ' + err.message);
      }
      res.send(`✅ Successfully imported ${result.affectedRows} leads from sheet "${sheetName}".`);
    });

  } catch (e) {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    res.status(500).send('Error reading file: ' + e.message);
  }
});

// ====================== START ======================
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});